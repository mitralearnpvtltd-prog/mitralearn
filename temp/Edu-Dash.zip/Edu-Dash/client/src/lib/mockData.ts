import { create } from 'zustand';

// Types
export interface Course {
  id: string;
  title: string;
  description: string;
  price: number;
  status: 'Active' | 'Inactive';
  enrolled: number;
  instructor: string;
  duration: string;
  category: string;
  startDate?: string;
  endDate?: string;
}

export interface Enrollment {
  id: string;
  userId: string;
  userName: string;
  courseId: string;
  courseName: string;
  enrollmentDate: string;
  isPaid: boolean;
  amountPaid: number;
  couponCode?: string;
  progress: number;
  status: 'Active' | 'Completed' | 'Dropped';
}

export interface Coupon {
  id: string;
  code: string;
  discountType: 'Percentage' | 'Flat';
  value: number;
  usage: number;
  limit: number;
  status: 'Active' | 'Expired' | 'Disabled';
  courseId?: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  phone: string;
  location: string;
  coursesEnrolled: number;
  progress: number;
  status: 'Active' | 'Inactive';
  role: 'Student' | 'Admin';
  registrationDate: string;
}

export interface Certificate {
  id: string;
  certificateId: string;
  userId: string;
  userName: string;
  courseId: string;
  courseName: string;
  issueDate: string;
  status: 'Issued' | 'Pending';
  type: 'Auto' | 'Manual';
}

export interface AnalyticsData {
  month: string;
  revenue: number;
  enrollments: number;
}

// Mock Data
const INITIAL_COURSES: Course[] = [
  { id: '1', title: 'Full Stack Web Development', description: 'Complete web development course covering frontend and backend.', price: 29999, status: 'Active', enrolled: 156, instructor: 'Sarah Johnson', duration: '12 weeks', category: 'Development', startDate: '2024-01-15' },
  { id: '2', title: 'Data Science & Machine Learning', description: 'Master data science and ML algorithms with Python.', price: 34999, status: 'Active', enrolled: 89, instructor: 'Dr. Michael Chen', duration: '16 weeks', category: 'Data Science' },
  { id: '3', title: 'UI/UX Design Masterclass', description: 'Learn modern UI/UX design principles and tools.', price: 19999, status: 'Active', enrolled: 234, instructor: 'Emma Williams', duration: '8 weeks', category: 'Design' },
  { id: '4', title: 'Cloud Computing with AWS', description: 'Become an AWS certified solutions architect.', price: 24999, status: 'Active', enrolled: 120, instructor: 'David Brown', duration: '10 weeks', category: 'Cloud' },
  { id: '5', title: 'Digital Marketing Pro', description: 'Complete digital marketing strategy and execution.', price: 14999, status: 'Inactive', enrolled: 45, instructor: 'Lisa Anderson', duration: '6 weeks', category: 'Marketing' },
  { id: '6', title: 'Cybersecurity Fundamentals', description: 'Introduction to network security and ethical hacking.', price: 22999, status: 'Active', enrolled: 67, instructor: 'Alex Martinez', duration: '8 weeks', category: 'Security' },
];

const INITIAL_USERS: User[] = [
  { id: '1', name: 'John Doe', email: 'john.doe@example.com', phone: '+1-555-0101', location: 'New York, USA', coursesEnrolled: 1, progress: 75, status: 'Active', role: 'Student', registrationDate: '2023-12-10' },
  { id: '2', name: 'Jane Smith', email: 'jane.smith@example.com', phone: '+1-555-0102', location: 'San Francisco, USA', coursesEnrolled: 2, progress: 73, status: 'Active', role: 'Student', registrationDate: '2024-01-05' },
  { id: '3', name: 'Mike Johnson', email: 'mike.j@example.com', phone: '+44-20-7946-0958', location: 'London, UK', coursesEnrolled: 1, progress: 30, status: 'Active', role: 'Student', registrationDate: '2024-01-15' },
  { id: '4', name: 'Sarah Williams', email: 'sarah.w@example.com', phone: '+1-555-0104', location: 'Austin, USA', coursesEnrolled: 1, progress: 15, status: 'Inactive', role: 'Student', registrationDate: '2024-02-01' },
  { id: '5', name: 'David Brown', email: 'david.brown@example.com', phone: '+61-2-9876-5432', location: 'Sydney, Australia', coursesEnrolled: 1, progress: 100, status: 'Active', role: 'Student', registrationDate: '2023-11-20' },
  { id: '6', name: 'Emily Davis', email: 'emily.d@example.com', phone: '+1-555-0106', location: 'Seattle, USA', coursesEnrolled: 1, progress: 60, status: 'Active', role: 'Student', registrationDate: '2024-01-25' },
  { id: '7', name: 'Alex Martinez', email: 'alex.m@example.com', phone: '+34-91-123-4567', location: 'Madrid, Spain', coursesEnrolled: 1, progress: 85, status: 'Active', role: 'Student', registrationDate: '2023-12-28' },
  { id: '8', name: 'Lisa Anderson', email: 'lisa.a@example.com', phone: '+1-555-0108', location: 'Boston, USA', coursesEnrolled: 1, progress: 100, status: 'Active', role: 'Student', registrationDate: '2023-11-05' },
];

const INITIAL_ENROLLMENTS: Enrollment[] = [
  { id: 'e1', userId: '1', userName: 'John Doe', courseId: '1', courseName: 'Full Stack Web Development', enrollmentDate: '2024-01-20', isPaid: true, amountPaid: 29999, couponCode: 'WELCOME50', progress: 75, status: 'Active' },
  { id: 'e2', userId: '2', userName: 'Jane Smith', courseId: '2', courseName: 'Data Science & Machine Learning', enrollmentDate: '2024-01-25', isPaid: true, amountPaid: 32999, couponCode: 'DATASCI2000', progress: 73, status: 'Active' },
  { id: 'e3', userId: '2', userName: 'Jane Smith', courseId: '3', courseName: 'UI/UX Design Masterclass', enrollmentDate: '2024-02-01', isPaid: true, amountPaid: 13999, progress: 60, status: 'Active' },
  { id: 'e4', userId: '3', userName: 'Mike Johnson', courseId: '4', courseName: 'Cloud Computing with AWS', enrollmentDate: '2024-02-10', isPaid: true, amountPaid: 24999, progress: 30, status: 'Active' },
  { id: 'e5', userId: '4', userName: 'Sarah Williams', courseId: '1', courseName: 'Full Stack Web Development', enrollmentDate: '2024-02-15', isPaid: false, amountPaid: 0, progress: 15, status: 'Dropped' },
  { id: 'e6', userId: '5', userName: 'David Brown', courseId: '1', courseName: 'Full Stack Web Development', enrollmentDate: '2024-01-10', isPaid: true, amountPaid: 29999, progress: 100, status: 'Completed' },
  { id: 'e7', userId: '6', userName: 'Emily Davis', courseId: '3', courseName: 'UI/UX Design Masterclass', enrollmentDate: '2024-02-05', isPaid: true, amountPaid: 19999, couponCode: 'DESIGN30', progress: 60, status: 'Active' },
  { id: 'e8', userId: '7', userName: 'Alex Martinez', courseId: '6', courseName: 'Cybersecurity Fundamentals', enrollmentDate: '2024-01-15', isPaid: true, amountPaid: 22999, progress: 85, status: 'Active' },
  { id: 'e9', userId: '8', userName: 'Lisa Anderson', courseId: '1', courseName: 'Full Stack Web Development', enrollmentDate: '2024-01-05', isPaid: true, amountPaid: 29999, progress: 100, status: 'Completed' },
];

const INITIAL_COUPONS: Coupon[] = [
  { id: '1', code: 'WELCOME50', discountType: 'Percentage', value: 50, usage: 67, limit: 100, status: 'Active' },
  { id: '2', code: 'DATASCI2000', discountType: 'Flat', value: 2000, usage: 34, limit: 50, status: 'Active', courseId: '2' },
  { id: '3', code: 'DESIGN30', discountType: 'Percentage', value: 30, usage: 156, limit: 200, status: 'Active', courseId: '3' },
  { id: '4', code: 'CLOUD1500', discountType: 'Flat', value: 1500, usage: 23, limit: 75, status: 'Active', courseId: '4' },
  { id: '5', code: 'EARLYBIRD', discountType: 'Percentage', value: 25, usage: 50, limit: 50, status: 'Disabled' },
];

const INITIAL_CERTIFICATES: Certificate[] = [
  { id: '1', certificateId: 'CERT-2024-001', userId: '2', userName: 'Jane Smith', courseId: '2', courseName: 'Data Science & Machine Learning', issueDate: '2024-04-15', status: 'Issued', type: 'Auto' },
  { id: '2', certificateId: 'CERT-2024-002', userId: '5', userName: 'David Brown', courseId: '1', courseName: 'Full Stack Web Development', issueDate: '2024-05-20', status: 'Issued', type: 'Auto' },
  { id: '3', certificateId: 'CERT-2024-003', userId: '8', userName: 'Lisa Anderson', courseId: '1', courseName: 'Full Stack Web Development', issueDate: '2024-04-21', status: 'Issued', type: 'Manual' },
];

export const REVENUE_DATA: AnalyticsData[] = [
  { month: 'Jan', revenue: 150000, enrollments: 3 },
  { month: 'Feb', revenue: 180000, enrollments: 2 },
  { month: 'Mar', revenue: 220000, enrollments: 2 },
  { month: 'Apr', revenue: 207492, enrollments: 2 },
];

export interface Notification {
  id: string;
  title: string;
  message: string;
  timestamp: string;
  read: boolean;
  type: 'info' | 'success' | 'warning' | 'error';
}

const INITIAL_NOTIFICATIONS: Notification[] = [
  { id: '1', title: 'New Enrollment', message: 'Jane Smith enrolled in Data Science & Machine Learning', timestamp: new Date(Date.now() - 5 * 60000).toISOString(), read: false, type: 'info' },
  { id: '2', title: 'Course Completed', message: 'David Brown completed Full Stack Web Development', timestamp: new Date(Date.now() - 15 * 60000).toISOString(), read: false, type: 'success' },
  { id: '3', title: 'Payment Received', message: 'Received ₹29,999 from Emily Davis for UI/UX Design', timestamp: new Date(Date.now() - 1 * 3600000).toISOString(), read: true, type: 'success' },
  { id: '4', title: 'Low Coupon Usage', message: 'EARLYBIRD coupon has expired', timestamp: new Date(Date.now() - 2 * 3600000).toISOString(), read: true, type: 'warning' },
];

// Store
interface AppState {
  courses: Course[];
  users: User[];
  enrollments: Enrollment[];
  coupons: Coupon[];
  certificates: Certificate[];
  notifications: Notification[];
  addCourse: (course: Omit<Course, 'id' | 'enrolled'>) => void;
  updateCourseStatus: (id: string, status: 'Active' | 'Inactive') => void;
  addCoupon: (coupon: Omit<Coupon, 'id'>) => void;
  toggleUserStatus: (id: string) => void;
  issueCertificate: (cert: Omit<Certificate, 'id' | 'issueDate' | 'status' | 'certificateId'>) => void;
  addEnrollment: (enrollment: Omit<Enrollment, 'id'>) => void;
  addNotification: (notification: Omit<Notification, 'id'>) => void;
  markNotificationAsRead: (id: string) => void;
  clearNotifications: () => void;
  getPaidEnrollments: () => number;
  getActiveUsers: () => number;
  getInactiveUsers: () => number;
  getUnreadNotificationCount: () => number;
}

export const useStore = create<AppState>((set, get) => ({
  courses: INITIAL_COURSES,
  users: INITIAL_USERS,
  enrollments: INITIAL_ENROLLMENTS,
  coupons: INITIAL_COUPONS,
  certificates: INITIAL_CERTIFICATES,
  notifications: INITIAL_NOTIFICATIONS,

  addCourse: (course) => set((state) => ({
    courses: [...state.courses, { ...course, id: Math.random().toString(36).substr(2, 9), enrolled: 0 }]
  })),

  updateCourseStatus: (id, status) => set((state) => ({
    courses: state.courses.map(c => c.id === id ? { ...c, status } : c)
  })),

  addCoupon: (coupon) => set((state) => ({
    coupons: [...state.coupons, { ...coupon, id: Math.random().toString(36).substr(2, 9) }]
  })),

  toggleUserStatus: (id) => set((state) => ({
    users: state.users.map(u => u.id === id ? { ...u, status: u.status === 'Active' ? 'Inactive' : 'Active' } : u)
  })),

  issueCertificate: (cert) => set((state) => ({
    certificates: [...state.certificates, { 
      ...cert, 
      id: Math.random().toString(36).substr(2, 9),
      certificateId: `CERT-${new Date().getFullYear()}-${Math.floor(Math.random() * 1000).toString().padStart(3, '0')}`,
      issueDate: new Date().toLocaleDateString(),
      status: 'Issued'
    }]
  })),

  addEnrollment: (enrollment) => set((state) => ({
    enrollments: [...state.enrollments, { ...enrollment, id: Math.random().toString(36).substr(2, 9) }]
  })),

  addNotification: (notification) => set((state) => ({
    notifications: [{ ...notification, id: Math.random().toString(36).substr(2, 9) }, ...state.notifications]
  })),

  markNotificationAsRead: (id) => set((state) => ({
    notifications: state.notifications.map(n => n.id === id ? { ...n, read: true } : n)
  })),

  clearNotifications: () => set((state) => ({
    notifications: state.notifications.map(n => ({ ...n, read: true }))
  })),

  getPaidEnrollments: () => get().enrollments.filter(e => e.isPaid).length,

  getActiveUsers: () => get().users.filter(u => u.status === 'Active').length,

  getInactiveUsers: () => get().users.filter(u => u.status === 'Inactive').length,

  getUnreadNotificationCount: () => get().notifications.filter(n => !n.read).length,
}));
